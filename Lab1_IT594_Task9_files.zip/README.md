# NLP Experiment Card Extractor

A transparent, **rule-based** baseline that extracts structured experimental
information (model, dataset, metric/score) from short NLP research
statements. No LLM, no neural classifier, and no pretrained information
extraction model is used anywhere in this system — every decision is made
by regular expressions, closed terminology lists, and spaCy's rule-based
`PhraseMatcher` / `Matcher`. spaCy is used only for tokenization (a blank
`en` pipeline; no statistical model is downloaded).

This baseline is meant to be compared later against a neural
sequence-labelling or relation-extraction model.

## 1. System Description

For each input sentence the pipeline produces one JSON "experiment card":

```json
{
  "text": "BERT-base achieved 91.3 F1 on CoNLL-2003.",
  "models": ["BERT-base"],
  "datasets": ["CoNLL-2003"],
  "results": [{"metric": "F1", "score": 91.3, "status": "final"}]
}
```

Pipeline stages (`experiment_card_extractor.py`):

1. **`normalize_text`** — collapses whitespace, preserves all wording.
2. **`build_nlp` / `build_matchers`** — a blank spaCy `en` tokenizer (with
   two small, documented customizations for consistent hyphen/period
   splitting) plus a `PhraseMatcher` (models & datasets) and a `Matcher`
   (result-reporting context + explicit negation, used as an auxiliary
   safety net).
3. **`extract_terminology`** — runs the `PhraseMatcher`, keeps the
   longest non-overlapping spans (`spacy.util.filter_spans`) so e.g.
   `"BERT-base"` wins over `"BERT"` and `"SQuAD 2.0"` wins over `"SQuAD"`.
4. **`extract_results`** — an ordered set of regex patterns (delta →
   paired final scores → `metric ... of ... number` → `metric number` →
   `number metric`) applied over normalized text, tracking consumed
   character spans so no number is claimed twice.
5. **`process_text` / `process_corpus`** — assembles one card per
   sentence.
6. **`save_jsonl`** — writes one JSON object per line.

## 2. Running the Code

```bash
pip install spacy      # no spaCy model download needed — blank pipeline only
python tests.py        # run the test suite (21 tests)
python - <<'PY'
from experiment_card_extractor import process_corpus, save_jsonl
cards = process_corpus(["BERT-base achieved 91.3 F1 on CoNLL-2003."])
save_jsonl(cards, "predictions.jsonl")
PY
```

Or open `experiment_card_extractor.ipynb` in Google Colab / Jupyter and
run all cells top to bottom — it installs spaCy, defines every component,
runs the development and test sets, runs the test suite, computes
precision/recall/F1, and writes `predictions.jsonl`.

## 3. Regex Patterns Used

| Pattern name        | Regex (simplified)                                                    | Status produced |
|----------------------|-------------------------------------------------------------------------|------------------|
| `delta`              | `improved (METRIC) by (NUM) points?`                                   | `delta`          |
| `pair_final`         | `(NUM) and (NUM) (METRIC)`                                             | `final` ×2       |
| `metric_of_num`      | `(METRIC) (score )?of (NUM)`                                           | `final`          |
| `metric_then_num`    | `(METRIC) (NUM)`                                                       | `final`          |
| `num_then_metric`    | `(NUM) %? (METRIC)`                                                    | `final`          |

`METRIC = F1|BLEU|ROUGE-L|EM|accuracy|precision|recall`, `NUM = \d+(\.\d+)?`.
Patterns are applied in the priority order above; once a character span is
consumed by an earlier pattern it cannot be re-matched by a later one.
Because every pattern requires a number to sit *directly* beside a
recognized metric name, years, dataset sizes, epoch counts, batch sizes,
and learning rates are never captured — no exclusion list is needed.

## 4. Matcher Types Used

- **`PhraseMatcher`** (`attr="ORTH"`) — matches a closed vocabulary of
  model names (`BERT-base`, `RoBERTa-large`, `T5-small`, `DistilBERT`,
  `BiLSTM-CRF`, `BART-large`, `DeBERTa-v3-large`, `ELECTRA-large`,
  `GPT-2`, …) and dataset names (`CoNLL-2003`, `SST-2`, `WMT14 En-De`,
  `AG News`, `CNN/DailyMail`, `BoolQ`, `MNLI-m`, `SQuAD 2.0`, …).
- **`Matcher`** — a token-level matcher used as an auxiliary check: one
  pattern flags reporting-verb context (`achieved`, `reached`, `scored`,
  …) and another flags explicit negation phrases (e.g. *"did not provide
  a numerical result"*) so that a sentence which explicitly denies a
  reported score never surfaces a result.

## 5. Precision, Recall, F1

Evaluated with exact-match tuples (`("MODEL", name)`, `("DATASET", name)`,
`("RESULT", metric, score, status)`) over the full development + test set
(20 sentences) against hand-verified gold annotations:

| Entity type | Precision | Recall | F1   |
|-------------|-----------|--------|------|
| Models      | 1.00      | 1.00   | 1.00 |
| Datasets    | 1.00      | 1.00   | 1.00 |
| Results     | 1.00      | 1.00   | 1.00 |
| **Overall** | **1.00**  | **1.00** | **1.00** |

These scores are perfect *on the provided development and test sets*
because the rules were designed directly against those templates — see
Limitations and `error_analysis.csv` for genuine failure cases on
unseen paraphrases.

## 6. Five Major Limitations

1. **Fixed adjacency requirement.** Every result pattern requires the
   metric name to sit immediately next to its number. Any paraphrase
   that inserts a verb, clause, or preposition between them (e.g.
   *"BERT-base's F1 ... was 91.3"*, *"... recorded at 90.9% for
   accuracy"*) is silently missed.
2. **Closed terminology vocabulary.** Model and dataset names must
   appear, character-for-character, in the hand-built lists. Genuinely
   unseen model names (e.g. `XLNet-large`, `Longformer`) are never
   extracted, even though the surrounding sentence is otherwise
   well-formed.
3. **No model–score linking.** When a sentence mentions several models
   and several scores, the system returns flat `models` and `results`
   lists with no indication of which score belongs to which model — it
   cannot resolve this correspondence at all.
4. **Fragile to superficial text variation.** Unicode look-alike
   characters (e.g. an en-dash `–` instead of a hyphen `-` in a model
   name) change the tokenization and break exact phrase matching,
   producing a wrong or partial extraction instead of the correct one.
5. **No long-distance or discourse-level reasoning.** Implicit
   comparisons (*"F1 improved from 89.0 to 91.3"*) and metrics separated
   from their score by a long relative clause are invisible to the
   system, since regex only looks at local, bounded windows of text.

## 7. Written Takeaway (330 words)

Rule-based systems handled surface-level, templated reporting reliably:
a known model name next to a known dataset name next to a metric
keyword sitting directly beside its number. Whenever the sentence
followed one of a small number of predictable templates — *achieved*,
*reached*, *obtained*, *scored*, *reported*, or *metric score of
number* — the `PhraseMatcher` and regex combination extracted models,
datasets, and results with perfect precision and recall on both the
development and test sets.

The rules that took the most manual effort were the result-extraction
regexes, not the terminology lists. Building the terminology
`PhraseMatcher` was mechanical once a vocabulary existed, but getting
the numeric patterns right required iterating on word order —
metric-then-number versus number-then-metric versus
metric-score-of-number — and adding a priority system with consumed
character spans so that a sentence with two numbers and one shared
metric, such as the "89.1 and 91.4 F1" case, was not double-counted or
merged incorrectly.

Negative examples changed the patterns substantially. An early, looser
version of the extractor treated any number close to a metric-like word
as a score, which meant epoch counts, batch sizes, and years were
sometimes captured. Writing explicit negative tests forced every
pattern to require direct adjacency to a recognized metric name, which
eliminated those false positives without needing a manually maintained
exclusion list.

Errors that cannot be fixed by adding one more keyword are the ones
rooted in syntax rather than vocabulary: long-distance dependencies
between a metric mention and its score, implicit deltas expressed as
"from X to Y," and unseen Unicode variants of known names. A contextual
encoder would improve recall here because it can represent a metric
and its number as related regardless of how many words or clauses
separate them, rather than relying on fixed-distance adjacency.

Even so, a hybrid system is often preferable to a fully neural one: the
rule-based layer is fully transparent, auditable, and free of silent
hallucinated model–score pairings, which matters when the output is
used to build a trustworthy baseline for comparison against neural
approaches.

## 8. Submission Structure

```
assessment_01/
├── experiment_card_extractor.ipynb   # Colab notebook (run top to bottom)
├── experiment_card_extractor.py      # importable module (used by the notebook & tests)
├── predictions.jsonl                 # experiment cards for dev + test sentences
├── tests.py                          # 21 tests (positive/negative/whitespace/etc.)
├── error_analysis.csv                # 5 documented failure cases
└── README.md                         # this file
```
