"""
Test suite for the NLP Experiment Card Extractor.

Run with:  python -m pytest tests.py -v
       or:  python tests.py            (falls back to a plain runner)

Coverage (see README.md for the mapping table):
  - 6 positive tests
  - 6 negative tests
  - 2 irregular-whitespace tests
  - 2 unseen-model-name tests
  - 2 multiple-numbers tests
  - 1 score-delta test
  - 1 multiple-models test
  - 1 multiple-results test
"""

from experiment_card_extractor import (
    build_nlp, build_matchers, process_text, normalize_text,
)

nlp = build_nlp()
phrase_matcher, token_matcher = build_matchers(nlp)


def run(text):
    return process_text(text, nlp, phrase_matcher, token_matcher)


# ---------------------------------------------------------------------------
# Positive tests (6) -- system should extract the expected information
# ---------------------------------------------------------------------------

def test_positive_final_f1():
    result = run("BERT-base achieved 91.3 F1 on CoNLL-2003.")
    assert result["models"] == ["BERT-base"]
    assert result["datasets"] == ["CoNLL-2003"]
    assert result["results"] == [{"metric": "F1", "score": 91.3, "status": "final"}]


def test_positive_accuracy_percent():
    result = run("DistilBERT scored 90% accuracy on AG News.")
    assert result["models"] == ["DistilBERT"]
    assert result["datasets"] == ["AG News"]
    assert result["results"] == [{"metric": "accuracy", "score": 90.0, "status": "final"}]


def test_positive_metric_then_number():
    result = run("On CNN/DailyMail, BART-large reported ROUGE-L 41.2.")
    assert result["results"] == [{"metric": "ROUGE-L", "score": 41.2, "status": "final"}]


def test_positive_score_of_phrase():
    result = run("On SQuAD 2.0, RoBERTa-large obtained an F1 score of 89.4.")
    assert result["datasets"] == ["SQuAD 2.0"]
    assert result["results"] == [{"metric": "F1", "score": 89.4, "status": "final"}]


def test_positive_accuracy_of_phrase():
    result = run("DeBERTa-v3-large reached an accuracy of 90.0 on BoolQ.")
    assert result["models"] == ["DeBERTa-v3-large"]
    assert result["datasets"] == ["BoolQ"]
    assert result["results"] == [{"metric": "accuracy", "score": 90.0, "status": "final"}]


def test_positive_bleu_score_of_phrase():
    result = run("T5-base delivered a BLEU score of 28.1 on WMT14 En-De.")
    assert result["results"] == [{"metric": "BLEU", "score": 28.1, "status": "final"}]


# ---------------------------------------------------------------------------
# Negative tests (6) -- system must NOT invent results / entities
# ---------------------------------------------------------------------------

def test_negative_dataset_size_is_not_score():
    result = run("The dataset contains 12,000 sentences.")
    assert result["results"] == []


def test_negative_year_is_not_score():
    result = run("The experiment was conducted in 2025.")
    assert result["results"] == []


def test_negative_epoch_count_is_not_score():
    result = run("BERT-base was trained for 10 epochs with batch size 32.")
    assert result["results"] == []


def test_negative_learning_rate_is_not_score():
    result = run("The learning rate was 2e-5.")
    assert result["results"] == []


def test_negative_model_mention_without_score():
    result = run("GPT-2 generated examples, but no evaluation score was reported.")
    assert result["models"] == ["GPT-2"]
    assert result["results"] == []


def test_negative_dataset_size_million_tokens():
    result = run("The corpus contains 91.3 million tokens.")
    assert result["results"] == []


# ---------------------------------------------------------------------------
# Irregular whitespace (2)
# ---------------------------------------------------------------------------

def test_whitespace_extra_spaces():
    raw = "BERT-base    achieved   91.3  F1   on CoNLL-2003."
    result = run(raw)
    assert result["text"] == normalize_text(raw)
    assert result["results"] == [{"metric": "F1", "score": 91.3, "status": "final"}]


def test_whitespace_newlines_and_tabs():
    raw = "RoBERTa-large\nreached\t94.8 accuracy\non SST-2."
    result = run(raw)
    assert "\n" not in result["text"] and "\t" not in result["text"]
    assert result["results"] == [{"metric": "accuracy", "score": 94.8, "status": "final"}]


# ---------------------------------------------------------------------------
# Unseen model names (2) -- documents a genuine system limitation
# ---------------------------------------------------------------------------

def test_unseen_model_name_not_in_terminology_list():
    result = run("XLNet-large achieved 92.1 F1 on SST-2.")
    # XLNet-large is not in the closed vocabulary, so it is correctly
    # left out rather than guessed at.
    assert result["models"] == []
    assert result["datasets"] == ["SST-2"]
    assert result["results"] == [{"metric": "F1", "score": 92.1, "status": "final"}]


def test_unseen_model_name_second_example():
    result = run("Longformer reported 88.2 accuracy on MNLI.")
    assert result["models"] == []
    assert result["datasets"] == ["MNLI"]
    assert result["results"] == [{"metric": "accuracy", "score": 88.2, "status": "final"}]


# ---------------------------------------------------------------------------
# Multiple numbers in one sentence (2)
# ---------------------------------------------------------------------------

def test_multiple_numbers_epochs_and_score():
    result = run("Using 16 epochs, BERT achieved 92% accuracy on AG News.")
    # 16 (epoch count) must be excluded; only 92 (accuracy) is kept.
    assert result["results"] == [{"metric": "accuracy", "score": 92.0, "status": "final"}]


def test_multiple_numbers_delta_and_final():
    result = run("The model improved F1 by 2.3 points and finished at 88.0 F1.")
    assert result["results"] == [
        {"metric": "F1", "score": 2.3, "status": "delta"},
        {"metric": "F1", "score": 88.0, "status": "final"},
    ]


# ---------------------------------------------------------------------------
# Score delta (1) -- duplicate-labelled for clarity, reuses the case above
# ---------------------------------------------------------------------------

def test_score_delta_only():
    result = run("The model improved BLEU by 1.5 points.")
    assert result["results"] == [{"metric": "BLEU", "score": 1.5, "status": "delta"}]


# ---------------------------------------------------------------------------
# Multiple models in one sentence (1)
# ---------------------------------------------------------------------------

def test_multiple_models_in_one_sentence():
    result = run("BERT-base and RoBERTa-large achieved 89.1 and 91.4 F1, respectively.")
    assert result["models"] == ["BERT-base", "RoBERTa-large"]


# ---------------------------------------------------------------------------
# Multiple results in one sentence (1)
# ---------------------------------------------------------------------------

def test_multiple_results_in_one_sentence():
    result = run("BERT-base and RoBERTa-large achieved 89.1 and 91.4 F1, respectively.")
    assert result["results"] == [
        {"metric": "F1", "score": 89.1, "status": "final"},
        {"metric": "F1", "score": 91.4, "status": "final"},
    ]


# ---------------------------------------------------------------------------
# Plain runner (used when pytest is not available)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    tests = [obj for name, obj in list(globals().items())
             if name.startswith("test_") and callable(obj)]
    passed, failed = 0, 0
    for t in tests:
        try:
            t()
            print(f"PASS  {t.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"FAIL  {t.__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed out of {len(tests)}")
    sys.exit(1 if failed else 0)
