"""
NLP Experiment Card Extractor
A transparent, rule-based (regex + spaCy PhraseMatcher/Matcher) baseline
for extracting structured experimental information from short NLP
research statements.

No LLM, no neural classifier, no pretrained IE model is used anywhere
in this file. spaCy is used only for tokenization and rule-based
matching (PhraseMatcher / Matcher).
"""

import re
import json
import spacy
from spacy.matcher import PhraseMatcher, Matcher
from spacy.util import filter_spans, compile_suffix_regex

# ---------------------------------------------------------------------------
# Terminology lists (closed vocabulary used by the PhraseMatcher)
# ---------------------------------------------------------------------------

KNOWN_MODELS = [
    "BERT-base", "BERT", "RoBERTa-large", "RoBERTa", "T5-small", "T5-base",
    "T5", "DistilBERT", "BiLSTM-CRF", "BART-large", "BART",
    "DeBERTa-v3-large", "DeBERTa", "ELECTRA-large", "ELECTRA", "GPT-2",
]

KNOWN_DATASETS = [
    "CoNLL-2003", "SST-2", "WMT14 En-De", "AG News", "CNN/DailyMail",
    "BoolQ", "MNLI-m", "MNLI", "SQuAD 2.0", "SQuAD",
]

METRIC_ALTERNATION = r"(?:F1|BLEU|ROUGE-L|EM|accuracy|precision|recall)"
NUM = r"\d+(?:\.\d+)?"

# ---------------------------------------------------------------------------
# Component 1: Text normalization
# ---------------------------------------------------------------------------

def normalize_text(text: str) -> str:
    """
    Normalize unnecessary whitespace while preserving
    the original linguistic content.

    - Collapses runs of whitespace (spaces, tabs, newlines) into a
      single space.
    - Strips leading/trailing whitespace.
    - Does NOT alter wording, casing, numbers, or punctuation.
    """
    if text is None:
        return ""
    collapsed = re.sub(r"\s+", " ", text)
    return collapsed.strip()


# ---------------------------------------------------------------------------
# spaCy pipeline set-up
#
# We use a blank English pipeline (tokenizer only -- no statistical
# model is downloaded or used). Two small tokenizer customizations are
# applied so that hyphenated / abbreviation-like tokens are split in a
# predictable, *consistent* way both when we build phrase patterns and
# when we tokenize input sentences:
#   1. Always split a trailing sentence period off the final token.
#   2. Remove the built-in single-letter abbreviation exceptions
#      ("m.", "n.", "a.") which otherwise swallow the period of
#      dataset names such as "MNLI-m.".
# Because the SAME tokenizer is used to build the PhraseMatcher
# patterns and to process the input text, matching stays correct even
# though the raw tokenizer behaviour on hyphens is not itself fully
# uniform.
# ---------------------------------------------------------------------------

def build_nlp():
    nlp = spacy.blank("en")
    suffixes = nlp.Defaults.suffixes + [r"(?<=[A-Za-z0-9])\.$"]
    nlp.tokenizer.suffix_search = compile_suffix_regex(suffixes).search
    rules = dict(nlp.tokenizer.rules)
    for bad in ("m.", "n.", "a."):
        rules.pop(bad, None)
    nlp.tokenizer.rules = rules
    return nlp


# ---------------------------------------------------------------------------
# Component 2: Matcher construction
# ---------------------------------------------------------------------------

def build_matchers(nlp):
    """
    Construct and return:
      1. A PhraseMatcher for known models and datasets.
      2. A Matcher for flexible result-reporting / negation patterns
         (used as a safety-net context check, complementing the regex
         based numeric extraction in extract_results()).
    """
    phrase_matcher = PhraseMatcher(nlp.vocab, attr="ORTH")
    model_patterns = [nlp.make_doc(m) for m in KNOWN_MODELS]
    dataset_patterns = [nlp.make_doc(d) for d in KNOWN_DATASETS]
    phrase_matcher.add("MODEL", model_patterns)
    phrase_matcher.add("DATASET", dataset_patterns)

    token_matcher = Matcher(nlp.vocab)

    # Flexible result-reporting pattern: a reporting verb, optionally
    # followed by a determiner/adjective, then a number and a metric
    # name in either order. This is used only as an auxiliary sanity
    # check (extract_results() does the authoritative numeric parsing
    # via regex, since it must also handle metric-then-number and
    # "X and Y METRIC" constructions that are awkward to express as a
    # single flat token pattern).
    token_matcher.add(
        "RESULT_CONTEXT",
        [
            [
                {"LOWER": {"IN": [
                    "achieved", "reached", "obtained", "scored",
                    "reported", "produced", "delivered", "finished",
                    "improved",
                ]}},
            ]
        ],
    )

    # Negation / "no result reported" context, used to suppress a
    # spurious numeric match that happens to sit in a sentence that
    # explicitly denies a reported score.
    token_matcher.add(
        "NO_RESULT_CONTEXT",
        [
            [{"LOWER": "no"}, {"LOWER": "evaluation"}, {"LOWER": "score"}],
            [{"LOWER": "did"}, {"LOWER": "not"}, {"LOWER": "provide"},
             {"LOWER": "a"}, {"LOWER": "numerical"}, {"LOWER": "result"}],
        ],
    )

    return phrase_matcher, token_matcher


# ---------------------------------------------------------------------------
# Component 3: Terminology extraction
# ---------------------------------------------------------------------------

def extract_terminology(doc, phrase_matcher) -> dict:
    """
    Return:
      {
        "models": [],
        "datasets": []
      }
    Longest, non-overlapping matches are kept (e.g. "BERT-base" wins
    over "BERT"; "SQuAD 2.0" wins over "SQuAD").
    """
    matches = phrase_matcher(doc)
    spans = [doc[start:end] for match_id, start, end in matches]
    spans = filter_spans(spans)  # longest match wins, no overlaps

    # filter_spans() drops the match_id, so re-derive the label
    # (MODEL / DATASET) per surviving span from the original matches.
    id_by_span = {}
    for match_id, start, end in matches:
        id_by_span[(start, end)] = doc.vocab.strings[match_id]

    seen_models, seen_datasets = [], []
    for span in spans:
        label = id_by_span.get((span.start, span.end))
        text = span.text
        if label == "MODEL" and text not in seen_models:
            seen_models.append(text)
        elif label == "DATASET" and text not in seen_datasets:
            seen_datasets.append(text)

    return {"models": seen_models, "datasets": seen_datasets}


# ---------------------------------------------------------------------------
# Component 4: Result extraction
# ---------------------------------------------------------------------------

# Ordered (priority) list of (name, compiled_pattern, kind) tuples.
# kind is one of "delta", "pair_final", "metric_of_num",
# "metric_then_num", "num_then_metric".
_RESULT_PATTERNS = [
    (
        "delta",
        re.compile(
            r"improved\s+(?P<metric>" + METRIC_ALTERNATION + r")\s+by\s+"
            r"(?P<score>" + NUM + r")\s+points?",
            re.IGNORECASE,
        ),
        "delta",
    ),
    (
        "pair_final",
        re.compile(
            r"(?P<score1>" + NUM + r")\s+and\s+(?P<score2>" + NUM + r")\s+"
            r"(?P<metric>" + METRIC_ALTERNATION + r")\b"
        ),
        "pair_final",
    ),
    (
        "metric_of_num",
        re.compile(
            r"(?P<metric>" + METRIC_ALTERNATION + r")\s+(?:score\s+)?of\s+"
            r"(?P<score>" + NUM + r")"
        ),
        "final",
    ),
    (
        "metric_then_num",
        re.compile(
            r"(?P<metric>" + METRIC_ALTERNATION + r")\s+"
            r"(?P<score>" + NUM + r")\b"
        ),
        "final",
    ),
    (
        "num_then_metric",
        re.compile(
            r"(?P<score>" + NUM + r")\s*%?\s*"
            r"(?P<metric>" + METRIC_ALTERNATION + r")\b"
        ),
        "final",
    ),
]


def _overlaps(span, used_spans):
    s, e = span
    return any(s < ue and e > us for us, ue in used_spans)


def extract_results(text: str) -> list:
    """
    Extract final scores and score deltas from raw text using regex.

    Each result is:
      {"metric": str, "score": float, "status": "final" | "delta"}

    Numbers that are years, dataset sizes, epoch counts, batch sizes
    or learning rates are never extracted because the patterns below
    only fire when a number sits directly next to a recognized metric
    name (F1, BLEU, ROUGE-L, EM, accuracy, precision, recall).
    """
    results = []
    used_spans = []  # character spans already consumed by a match

    for name, pattern, kind in _RESULT_PATTERNS:
        for m in pattern.finditer(text):
            span = m.span()
            if _overlaps(span, used_spans):
                continue
            if kind == "delta":
                results.append({
                    "metric": m.group("metric"),
                    "score": float(m.group("score")),
                    "status": "delta",
                })
                used_spans.append(span)
            elif kind == "pair_final":
                metric = m.group("metric")
                results.append({
                    "metric": metric,
                    "score": float(m.group("score1")),
                    "status": "final",
                })
                results.append({
                    "metric": metric,
                    "score": float(m.group("score2")),
                    "status": "final",
                })
                used_spans.append(span)
            else:  # "final"
                results.append({
                    "metric": m.group("metric"),
                    "score": float(m.group("score")),
                    "status": "final",
                })
                used_spans.append(span)

    return results


# ---------------------------------------------------------------------------
# Component 5: Complete processing
# ---------------------------------------------------------------------------

def process_text(text: str, nlp, phrase_matcher, token_matcher) -> dict:
    """
    Produce one complete experiment card for a single input sentence.
    """
    clean_text = normalize_text(text)
    doc = nlp(clean_text)

    terminology = extract_terminology(doc, phrase_matcher)
    results = extract_results(clean_text)

    # Safety net: if the sentence explicitly denies a numerical
    # result, do not report any (guards against a future pattern
    # accidentally firing on such sentences).
    neg_matches = [m for m in token_matcher(doc)
                   if doc.vocab.strings[m[0]] == "NO_RESULT_CONTEXT"]
    if neg_matches:
        results = []

    return {
        "text": clean_text,
        "models": terminology["models"],
        "datasets": terminology["datasets"],
        "results": results,
    }


# ---------------------------------------------------------------------------
# Component 6: Corpus processing
# ---------------------------------------------------------------------------

def process_corpus(texts: list) -> list:
    """
    Process all input texts and return experiment cards.
    """
    nlp = build_nlp()
    phrase_matcher, token_matcher = build_matchers(nlp)
    return [process_text(t, nlp, phrase_matcher, token_matcher) for t in texts]


# ---------------------------------------------------------------------------
# Component 7: JSONL export
# ---------------------------------------------------------------------------

def save_jsonl(records: list, output_path: str) -> None:
    with open(output_path, "w", encoding="utf-8") as file:
        for record in records:
            file.write(json.dumps(record, ensure_ascii=False) + "\n")


# ---------------------------------------------------------------------------
# Component 8: Evaluation
# ---------------------------------------------------------------------------

def precision_recall_f1(predicted, gold):
    predicted = set(predicted)
    gold = set(gold)
    true_positive = len(predicted & gold)
    false_positive = len(predicted - gold)
    false_negative = len(gold - predicted)
    precision = (
        true_positive / (true_positive + false_positive)
        if true_positive + false_positive else 0.0
    )
    recall = (
        true_positive / (true_positive + false_negative)
        if true_positive + false_negative else 0.0
    )
    f1 = (
        2 * precision * recall / (precision + recall)
        if precision + recall else 0.0
    )
    return {"precision": precision, "recall": recall, "f1": f1}


def card_to_tuples(card: dict):
    """Convert one experiment card into (MODEL/DATASET/RESULT) tuples."""
    model_tuples = [("MODEL", m) for m in card["models"]]
    dataset_tuples = [("DATASET", d) for d in card["datasets"]]
    result_tuples = [
        ("RESULT", r["metric"], r["score"], r["status"])
        for r in card["results"]
    ]
    return model_tuples, dataset_tuples, result_tuples
